/* PWA install helper: include this file once, near </body>. */
(() => {
  if (window.__pwaInstallHelperLoaded) return;
  window.__pwaInstallHelperLoaded = true;

  let installPrompt = null;

  const isStandalone = () =>
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true;

  function addInstallButton() {
    if (!document.body || document.getElementById("pwa-install-btn") || isStandalone()) return;

    const button = document.createElement("button");
    button.id = "pwa-install-btn";
    button.type = "button";
    button.textContent = "📲 Pasang sebagai app";
    button.setAttribute("aria-label", "Pasang aplikasi pada peranti");

    Object.assign(button.style, {
      position: "fixed",
      left: "50%",
      bottom: "calc(16px + env(safe-area-inset-bottom, 0px))",
      transform: "translateX(-50%)",
      zIndex: "99999",
      display: "block",
      maxWidth: "calc(100vw - 32px)",
      padding: "12px 18px",
      border: "0",
      borderRadius: "999px",
      background: "#1976d2",
      color: "#fff",
      font: "600 15px/1.3 system-ui, sans-serif",
      boxShadow: "0 4px 16px rgba(0,0,0,.24)",
      cursor: "pointer"
    });

    document.body.appendChild(button);

    button.addEventListener("click", async () => {
      if (installPrompt) {
        const promptEvent = installPrompt;
        installPrompt = null;
        try {
          await promptEvent.prompt();
          const choice = await promptEvent.userChoice;
          if (choice && choice.outcome === "accepted") button.remove();
        } catch (error) {
          console.error("PWA install prompt failed:", error);
          showManualInstructions();
        }
        return;
      }
      showManualInstructions();
    });

    function showManualInstructions() {
      const ua = navigator.userAgent || "";
      const isIOS = /iphone|ipad|ipod/i.test(ua);
      if (isIOS) {
        alert("Untuk memasang aplikasi pada iPhone/iPad:\n\n1. Buka laman ini dalam Safari.\n2. Tekan Share.\n3. Pilih Add to Home Screen.\n4. Tekan Add.");
      } else {
        alert("Pilihan pemasangan belum diberikan oleh pelayar.\n\nDalam Chrome Android, tekan menu ⋮ dan cari 'Install app' atau 'Add to Home screen'. Jika pilihan tiada, semak manifest.json, ikon, HTTPS dan Service Worker.");
      }
    }
  }

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    installPrompt = event;
  });

  window.addEventListener("appinstalled", () => {
    installPrompt = null;
    const button = document.getElementById("pwa-install-btn");
    if (button) button.remove();
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addInstallButton, { once: true });
  } else {
    addInstallButton();
  }

  if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/sw.js").catch((error) => {
        console.error("Service Worker registration failed:", error);
      });
    }, { once: true });
  }
})();
