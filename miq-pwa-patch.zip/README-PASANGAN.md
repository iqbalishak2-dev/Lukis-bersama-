# PWA patch untuk projek HTML/CSS/JavaScript (GitHub + Render)

Pakej ini menambah komponen PWA tanpa menggantikan UI atau logik aplikasi sedia ada.

## 1. Muat naik fail ke root repository GitHub

Letakkan fail/folder ini pada root projek (aras yang sama dengan `index.html`):
- `manifest.json`
- `sw.js`
- `pwa-install.js`
- `icons/icon-192.png`
- `icons/icon-512.png`

Jika repository anda menyimpan `index.html` dalam subfolder, laluan `/manifest.json`, `/sw.js` dan `/icons/...` perlu disesuaikan.

## 2. Tambah dua baris dalam `<head>` index.html

Letakkan sebelum `</head>`:

```html
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#1976d2">
```

Jika sudah ada `theme-color`, kemas kini yang sedia ada, jangan gandakan.

## 3. Tambah script sebelum `</body>`

Letakkan sebelum tag `</body>`:

```html
<script src="/pwa-install.js" defer></script>
```

Jangan letakkan script selepas `</html>` atau di luar tag HTML.

## 4. Buang kod PWA lama yang berganda

Jika `index.html` sudah mengandungi kod lama yang mencipta butang "Pasang sebagai app" atau mendaftarkan `/sw.js`, keluarkan blok lama itu sahaja selepas anda memasang script baharu. Jangan padam fungsi aplikasi yang lain.

## 5. Sesuaikan nama aplikasi

Edit `manifest.json`:
- `name`: nama penuh aplikasi
- `short_name`: nama ringkas pada skrin utama
- `description`: penerangan aplikasi

Ikon dalam pakej ini ialah ikon placeholder neutral. Gantikan dengan logo aplikasi anda jika mahu, tetapi kekalkan saiz dan laluan fail yang sama.

## 6. Commit dan deploy Render

1. Commit fail baharu dan perubahan `index.html` ke branch yang dipantau Render.
2. Tunggu deploy berjaya, atau pilih Manual Deploy → Deploy latest commit.
3. Buka `https://DOMAIN-RENDER-ANDA/manifest.json` dan pastikan JSON dipaparkan.
4. Buka `https://DOMAIN-RENDER-ANDA/sw.js` dan pastikan kod JavaScript dipaparkan.
5. Buka laman utama menggunakan Chrome Android, refresh, kemudian cuba butang pemasangan.

## Nota penting
- Aplikasi perlu dilayan melalui HTTPS untuk pemasangan PWA di luar localhost.
- Paparan butang tidak menjamin Chrome menawarkan prompt pemasangan. Manifest, ikon, Service Worker dan syarat pelayar mesti betul.
- iPhone/iPad: buka melalui Safari → Share → Add to Home Screen.
- `sw.js` ini menyediakan cache asas halaman utama dan aset statik. Ia bukan jaminan semua fungsi atau data aplikasi boleh digunakan offline. API, data dinamik, dan fail yang tidak pernah dicache mungkin memerlukan internet.
- Selepas mengubah Service Worker, jika hasil lama masih kelihatan, tutup dan buka semula laman; jika perlu, clear site data/cache untuk domain aplikasi.
